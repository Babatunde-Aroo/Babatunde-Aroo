# CMPS 6100 Lab 07
## Answers

**Name:** _Augustine Babatunde Arogundade_

Place all written answers from `lab-07.md` here.

# Secrets (4 pts)

1. What value is stored in `[rbp-0x4]`, what operations are performed on 
it, and what is the final result of the operations? In assembly, the 
values are given in hexadecimal. Give your answers in decimal (base-10).

The instruction at line 1129: This line assigns the hexadecimal value 0x5dc to [rbp-0x4].
Converting 0x5dc to decimal:
# 0x5dc = 1500 (decimal)

  The Operations Performed:
Line 1130: This moves the value of [rbp-0x4] (which is 1500) into the edx register.
Line 1133: This moves the value in edx (1500) into the eax register.
Line 1135: This adds the value of eax to itself (1500 + 1500), resulting in 3000.
Line 1137: This adds the value of edx (1500) to eax (3000 + 1500), resulting in 4500.
Line 1139: This stores the current value of eax (4500) back into [rbp-0x4].
Line 113c: This adds 0x5dc (1500 in decimal) to [rbp-0x4] (4500 + 1500), resulting in 6000.
Line 1143: This adds 0x44 (68 in decimal) to [rbp-0x4] (6000 + 68), resulting in 6068.
Line 1147: This adds 0x20 (32 in decimal) to [rbp-0x4] (6068 + 32), resulting in 6100.
Final Value: The final value stored in [rbp-0x4] after all the operations is 6100

  Summary:
o Initial value stored in [rbp-0x4]: 1500
o Operations performed:
o Multiply by 2 (3000)
o Add original value (4500)
o Add 1500 (6000)
o Add 68 (6068)
o Add 32 (6100)
• Final result: 6100 (decimal)



# C Variables and Pointers (2.5 pts)

3. Playing in `pointer.c`

    a. Print out the memory addresses of `num1` and `num2`. What values did you assign to `num1` and `num2`? What are the memory addresses of `num1` and of `num2`?
    o Memory address of num1: 0x7ffc0b32436c
    o Memory address of num2: 0x7ffc0b324368



    b. Declare two pointers to ints, `ptr1` and `ptr2` and assign into them the memory addresses of `num1` and `num2`. Using the dereference operator, print out the values pointed to by `ptr1` and `ptr2`.
    o Value pointed to by ptr1: 10
    o Value pointed to by ptr2: 20



    c. It is possible to increment or decrement a pointer. Increment `prt2` by 1. Print out the memory address now stored in `ptr2`. How does this relate to `ptr1`?
    
    0x7ffc0b32436c
    0x7ffc0b324368
    Value pointed to by ptr1: 10
    Value pointed to by ptr2: 20
   * Memory address of ptr2 after decrementing: 0x7ffc0b324364 
    Value of num1: 10
    Value of num2: 30
      


    d. Finally, using the dereference operator, update the value pointed to by `ptr2` to be a new value. Now print out `num1`. What happened?

    * When updating the value pointed to by `ptr2`, the value of `num2` became 30.



    e. What does all of this tell you about memory safety in C? Does C protect variables from indirect access via pointers?

      C does not inherently protect variables from indirect access via pointers. It allows for direct manipulation
       of memory, which can lead to issues like segmentation faults if pointers are not handled carefully.
      Programmers must manually manage memory and ensure pointers point to valid memory addresses before dereferencing them.



## Arrays (2.5 pts)

4. In `array.c` an array has been declared for you. Print out it's contents using a [`for` loop](https://www.tutorialspoint.com/cprogramming/c_for_loop.htm). What do you see?
    
    a. Record the contents of your array here.
    0
    1
    2
    3
    4
    5
    6
    7
    8
    9

    First element: 0
    Last element: 9



    b. Run your program several times. Do the values change? Speculate about what you are seeing.

     It yielded consistent results on each run.


    c. Modify your `for` loop to continue printing values past the end
    of the array. Access and print the values from your array for
    indices 0-14. Does C allow you to do this?

      In C, accessing and printing values beyond the bounds of an array (for indices 0-14) is technically allowed,
       but it leads to undefined behavior which showed “Segmentation fault” (relating to the misuse of pointers.).
       Therefore, the loop limits must be based on the size of the array to prevent writing or reading to memory 
      locations out of bounds.


    d. In C, an array variable is a pointer to the first memory address of the array. Where is the array `arr` stored in memory? Print out the memory address of the beginning of `arr`. What is the memory address where arr[0] is stored? What is the memory address where arr[1] stored?

      Memory address of arr: 0x7ffc49547d10
      Memory address of arr[0]: 0x7ffc49547d10
      Memory address of arr[1]: 0x7ffc49547d14



    e. What does the difference between the memory addresses `arr[0]` 
    and `arr[1]` tell you about the size of an integer? How many bytes of
    memory does an int require?

    In C, memory addresses for array elements are sequentially incremented based on the size of the data type 
    stored in the array. Thus, the difference between the addresses of consecutive elements (arr[0] and arr[1])
    indicates the number of bytes required to store one int.
    The differences between the addresses, in this case, is 0x4 (or 4 bytes in decimal). 
    This indicates that each int occupies 4 bytes of memory on this system.





## Command Line Arguments (1 pts)

5. Implement a program, `cmdargs.c` which takes in command line arguments and prints each one to stdout on a new line.

## String Splitting (15 pts)

6. Implement the function `parseline`. 
