#include <stdio.h>

int main() {
    // print "Hello, World!"
    // first comment typed by me!
    printf("Hello, World!\n");
    int num = 5;
    // types in C
    // numeric types:
    // byte - 8 bits
    // short - 16 bits
    // int - 32 bits
    // long - 64 bits
    //
    // the size of bit determines the number
    // of values we can represent.
    // with a single bit, you can represent 2 values
    // with a 2 bits, you can represent 4 values
    // 00 - 0
    // 01 - 1
    // 10 - 2
    // 11 - 3
    // with a 3 bits, you can represent 8 values
    // 000 - 0
    // 001 - 1
    // 010 - 2
    // 011 - 3
    // 100 - 4
    // 101 - 5
    // 110 - 6 
    // 111 - 7
    // for a byte (8 bits), 256 values

    // float - 32 bits
    // doubles - 64 bits
    // characters
    // char
    char letter = 'a';

    // Arrays in C
    // in Python, we have the basic type of list
    // in C, we use arrays for the same purpose
    char str[10];
    str[0] = 'A';
    str[1] = ' ';
    str[2] = 's';
    str[3] = '\n';
    str[4] = '\0';
    printf(str);

    int arr[3] = {1,2,3};


    // string in C
 
    //   
    return 0;
}
