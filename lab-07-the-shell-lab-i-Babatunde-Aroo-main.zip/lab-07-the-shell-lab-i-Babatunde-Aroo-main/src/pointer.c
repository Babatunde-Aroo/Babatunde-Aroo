#include <stdio.h>

int main() {

 
     // Declare and initialize two integers
     int num1 = 10; // Assign an arbitrary value to num1
     int num2 = 20; // Assign a different arbitrary value to num2

     // Print the memory addresses of num1 and num2
     printf("%p\n", &num1);
     printf("%p\n", &num2);


     // Declare two pointers to int
     int* ptr1;
     int* ptr2;

     // Assign the memory addresses of num1 and num2 to the pointers
     ptr1 = &num1;
     ptr2 = &num2;

     printf("stored memory address = %p\n", ptr1);
     printf("stored memory address = %p\n", ptr2);


     // Print the values pointed to by ptr1 and ptr2 using the dereference operator
     printf("Value pointed to by ptr1: %d\n", *ptr1);
     printf("Value pointed to by ptr2: %d\n", *ptr2);

     // decrement ptr2 by 1
     ptr2--;

     // Print the new memory address of ptr2 after decrementing
     printf("Memory address of ptr2 after decrementing: %p\n", ptr2);

    // Update the value pointed to by ptr2
    *ptr2 = 30; 

    // Print the values of num1 and num2
    printf("Value of num1: %d\n", *ptr1);
    printf("Value of num2: %d\n", *ptr2);


      
    return 0;

}
