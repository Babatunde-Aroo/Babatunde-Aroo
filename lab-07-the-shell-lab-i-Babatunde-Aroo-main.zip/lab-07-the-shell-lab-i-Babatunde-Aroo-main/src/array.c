#include <stdio.h>

int main() {
    int arr[10];
    // print out the contents of arr
    // Initialize the array with values    
    for (int i = 0; i < 10; i++) {
        arr[i] = i; // Assign values to the array elements
    }

    // Print out the contents of arr using a for loop
    for (int i = 0; i < 10; i++) {
        printf("%d\n", arr[i]); // Print each element of the array
    }       
    // print out the first thing in the array
    printf("\nFirst element: %d\n", arr[0]);
    // print out the last thing in the array
    printf("Last element: %d\n", arr[9]);

    // Print the memory address of the beginning of the array
    printf("Memory address of arr: %p\n", &arr);

    // Print the memory address of arr[0]
    printf("Memory address of arr[0]: %p\n", &arr[0]);

    // Print the memory address of arr[1]
    printf("Memory address of arr[1]: %p\n", &arr[1]);



    
    return 0;
}
