#include <stdio.h>

int main(int argc, char* argv[]) {
    // Print out all cmd line args to stdout
    // Loop through each command-line argument
    for (int i = 0; i < argc; i++) {
        // Print each argument on a new line
        printf("%s\n", argv[i]);
    }
    
    return 0;
}
