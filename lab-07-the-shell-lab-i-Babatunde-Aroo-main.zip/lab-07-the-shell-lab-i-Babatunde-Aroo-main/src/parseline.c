#include <stdio.h>
#include <string.h>


#define MAXLINE    1024   /* max line size */
#define MAXARGS     128   /* max args on a command line */

int parseline(const char *cmdline, char* argv[]) 
{
    static char array[MAXLINE]; // holds local copy of command line
    char *buf = array;          // ptr that traverses command line
    char *delim;                // points to the first space delimiter
    int argc;                   // number of arguments
    int bg;                     // background job?

    strcpy(buf, cmdline);       // copy cmd into buf
    buf[strlen(buf)-1] = ' ';   // replace trailing '\n' with space

    // Ignore leading spaces
    while (*buf && (*buf == ' '))
        buf++;

    // Build the argv list
    argc = 0;
    int in_quotes = 0; // flag to check if inside single quotes

    while ((delim = strchr(buf, ' ')) != NULL || (delim = strchr(buf, '\0')) != NULL) {
        if (*buf == '\'') { // handle single quotes
            in_quotes = 1;
            buf++; // move past the initial quote
            delim = strchr(buf, '\''); // find the closing quote
            if (delim != NULL) {
                *delim = '\0';
                argv[argc++] = buf;
                buf = delim + 1;
            }
            in_quotes = 0;
        } else {
            // Add the argument to argv
            *delim = '\0'; // terminate the current argument
            argv[argc++] = buf;
            buf = delim + 1;
        }

        // Ignore spaces between arguments
        while (*buf && (*buf == ' '))
            buf++;
        
        if (*buf == '\0') {
            break;
        }
    }

    // The last argument must be NULL
    argv[argc] = NULL;

    // Check if the job should run in the background
    if (argc > 0 && strcmp(argv[argc-1], "&") == 0) {
        bg = 1;
        argv[--argc] = NULL; // remove the "&" from the argument list
    } else {
        bg = 0;
    }

    return bg;
}
