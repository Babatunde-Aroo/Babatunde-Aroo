# CMPS 6100 Lab 04
## Answers

**Name:**_Augustine Babatunde Arogundade (I uploaded a pdf file to the solutions)


Place all written answers from `lab-04.md` here.

## Asymptotic Analysis Problems (1 pt ea.)

1. $T(n) = 3T(n/2) + n$



2. $T(n) = 2T(n/3) + 1$



3. $T(n) = 4T(n/16) + n^{1/4}$



4. $T(n) = T(n-1) + n$



5. $T(n) = 3T(n/3) + n$



6. $T(n) = 2T(n/2) + n^2$



7. $T(n) = 4T(n/2) + n^2$



8. $T(n) = 8T(n/2) + n^2$



## Coding Problems Analysis

### Unimodal Max (2 pts)

12. Prove that your **Unimodal Max** algorithm runs in $O(\lg n)$ work by deriving the recurrence for your algorithm and solving it.

## Sorting Analysis

14.  Use `print_results` to print a table of selection sort and merge sort's runtimes for each of the sizes: 

    `[100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]`
    
|    n |   Selection Sort |   Merge Sort |
|------|------------------|--------------|
|  100 |            0.161 |        0.000 |
|  200 |            1.010 |        0.000 |
|  300 |            1.997 |        0.502 |
|  400 |            3.006 |        1.480 |
|  500 |            5.042 |        1.708 |
|  600 |            8.540 |        0.000 |
|  700 |           11.706 |        0.000 |
|  800 |           18.464 |        0.000 |
|  900 |           30.124 |        0.000 |
| 1000 |           32.224 |        0.000 |


15. Add plots for the runtimes of Selection Sort and Merge Sort for each of the following lists of sizes:

    1. `[10, 20, 30, 40, 50, 60, 70, 80, 90, 100]`

    2. `[100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]`

    3. `[1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]`
    

![alt text](Figure_0.png)

![alt text](Figure_1.png)

![alt text](Figure_2.png)



16.  Do your results match your expectations? That is, are the trends that you see between the Selection Sort and Merge Sort's runtimes what you expected? Why or why not?
Yes, the results match expectations; merge sort consistently outperforms selection sort as input sizes increase, which is expected due to merge sort’s time complexity compared to selection sort’s.

17.  How long does it take your computer to sort lists of sizes `[1000, 10000, 100000]` using Selection Sort and Merge Sort? Based on this, how long would you expect Selection Sort to take to sort a list of size 1,000,000? Express this in minutes, hours, or days, which ever is the appropriate scale. How long does it take Merge Sort to sort a list of 1,000,000?

Size: 1000, Selection Sort: 23.60 ms, Merge Sort: 0.00 ms
Size: 10000, Selection Sort: 2720.05 ms, Merge Sort: 19.89 ms
Size: 100000, Selection Sort: 254153.30 ms, Merge Sort: 194.87 ms

for a size of 1000000, the selection sort is 7.06 hrs and the merge sort is 2.35 s


[text](<Lab 4.pdf>)