"""
CMPS 6100  Lab 4
Author: Augustine Babatunde Arogundade
"""

## Add any imports here
import tabulate
import matplotlib.pyplot as plt
import time
##

###########    ###########
###    Unimodal Max    ###
###########    ###########

def unimodal_max(lst):
    # TO-DO: Implement this function

    if len(lst) == 0:
        return None  # Handle edge case of empty list
   
    def find_peak(lst, left, right):
        if left == right:
            return lst[left]  # Base case: single element left
        
        mid = (left + right) // 2
        
        # If middle element is greater than the next one, peak is on the left half
        if lst[mid] > lst[mid + 1]:
            return find_peak(lst, left, mid)
        else:
            # Otherwise, peak is on the right half
            return find_peak(lst, mid + 1, right)
    
    return find_peak(lst, 0, len(lst) - 1)

# Example usage
lst = [0, 1, 2, 4, 5, 10, 7, 6, 3]
largest = unimodal_max(lst)
print(largest)  

### Test Function ###

def test_unimodal_max():
    lst = [4, 5, 7, 6, 3, 2, 1, 0]
    assert(unimodal_max(lst) == 7)
    lst = [1, 2, 3, 4, 5, 6, 7, 8]
    assert(unimodal_max(lst) == 8)
    lst = [9, 8, 7, 6, 5, 4, 3, 2]
    assert(unimodal_max(lst) == 9)

###########    ###########
###  Sorting Analysis  ###
###########    ###########


def selection_sort(L):
    """ done. """
    lst = list(L)
    # For every position in the list
    for position in range(len(lst)):

        # find the minimum element from that position to the end
        minimum_element_index = position 
        for index in range(position,len(lst)):
            element = lst[index]
            # if the current element is smaller than the smallest found so far
            if element < lst[minimum_element_index]:
                # update the minimum element index
                minimum_element_index = index

        # and swap it into position
        lst[position], lst[minimum_element_index] = lst[minimum_element_index], lst[position]
    return lst

def merge_sort(lst):
    """ done. """
    if len(lst) == 1 or len(lst) == 0:
        return lst
    
    mid = len(lst) // 2
    left = merge_sort(lst[:mid])
    right = merge_sort(lst[mid:])

    return merge(left, right)

def merge(left, right):
    """
    Merge two sorted lists, left and right, into one sorted list.
    This function is implemented iteratively to avoid recursion depth
    issues.

    done.
    """
    merged_list = []
    l = 0
    r = 0
    # Repeatedly move the smallest of left and right to the new list
    while l < len(left) and r < len(right):
        if left[l] <= right[r]:
            merged_list.append(left[l])
            l += 1
        else:
            merged_list.append(right[r])
            r += 1
    # There will only be elements left in one of the original two lists.

    # Append the remains of left (l..end) on to the new list.
    merged_list.extend(left[l:])
    # Append the remains of right (r..end) on to the new list.
    merged_list.extend(right[r:])
    return merged_list

def is_sorted(lst):
    """
    Return True if lst is sorted, False otherwise

    Params:
        lst.....a list of values

    Returns:
        True if the list is sorted, False otherwise
    """
    # TO-DO: Implement this
    for i in range(len(lst) - 1):
        if lst[i] > lst[i + 1]:  # If an element is greater than the next
            return False
    return True  # No violations, so the list is sorted
print(is_sorted([1, 2, 3, 4, 5])) 

#manually checking if the input list is sorted

def list_sum_DC(lst):
    # If the list is empty, the sum is 0 (Base case)
    if not lst:
        return 0

    # return that element, if the list has only one element,
    if len(lst) == 1:
        return lst[0]

    # Divide the list into two halves.
    mid = len(lst) // 2
    left_half = lst[:mid]
    right_half = lst[mid:]

    # Recursively calculate the sum of sublists.
    left_sum = list_sum_DC(left_half)
    right_sum = list_sum_DC(right_half)

    # Combine the outputs and return the total sum.
    tot_sum = left_sum + right_sum
    return tot_sum

lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

output = list_sum_DC(lst)

print("Sum of the list:", output)



def test_is_sorted():
    """ done. """
    assert is_sorted([])
    assert is_sorted([1])
    assert is_sorted([1,2])
    assert not is_sorted([2,1])

    assert is_sorted([1,2,3,4,5])
    assert not is_sorted([1,2,3,5,4])
    assert not is_sorted([5,4,3,2,1])
    assert not is_sorted([2,3,1,5,4])

def test_selection_sort():
    """ done. """
    assert is_sorted(selection_sort([]))# == []
    assert is_sorted(selection_sort([101]))# == [101]
    assert is_sorted(selection_sort([1,2,3,4,5]))# == [1,2,3,4,5]
    assert is_sorted(selection_sort([5,4,3,2,1]))# == [1,2,3,4,5]
    assert is_sorted(selection_sort([2,3,1,5,4]))# == [1,2,3,4,5]

def test_merge_sort():
    """ done. """
    assert is_sorted(merge_sort([]))# == []
    assert is_sorted(merge_sort([101]))# == [101]
    assert is_sorted(merge_sort([101, 99]))# == [99, 101]
    assert is_sorted(merge_sort([101, 99, 97]))# == [97, 99, 101]
    assert is_sorted(merge_sort([1,2,3,4,5]))# == [1,2,3,4,5]
    assert is_sorted(merge_sort([5,4,3,2,1]))# == [1,2,3,4,5]
    assert is_sorted(merge_sort([2,3,1,5,4]))# == [1,2,3,4,5]

def get_sorting_time(sort_fn, lst):
    """
    Return the number of milliseconds to run this
    sort function on the list.

    Usage:
        lst = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
        t = get_sorting_time(selection_sort, lst)

    Note 1: You can use time.time() which returns the current 
    time in seconds. You'll have to multiple by 1000 to get 
    milliseconds.

    Params:
        sort_fn.....the sort function
        lst......the list to sort

    Returns:
        the number of milliseconds it takes to run this
        sorting function on this input.
    """
    # TO-DO: Implement this
    start_time = time.time()  # Get the current time in seconds
    sort_fn(lst)  # Run the sorting function on the list
    end_time = time.time()  # Get the end time in seconds
    
    elapsed_time_ms = (end_time - start_time) * 1000  # Convert to milliseconds
    return elapsed_time_ms

# usage
lst = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
ss_time = get_sorting_time(selection_sort, lst)
ms_time = get_sorting_time(merge_sort, lst)

print(f"Selection sort time: {ss_time:.2f} ms")
print(f"Merge sort time: {ms_time:.2f} ms")



def benchmark_sorting_algs(sizes=[ 1000,  2000,  3000,  4000,  5000,  6000,  7000,  8000,  9000, 10000, 
                                  11000, 12000, 13000, 14000, 15000, 16000, 17000, 18000, 19000, 20000]):
    """
    Get the run times of selection_sort and merge_sort on lists
    for input sizes given. The list to sort for each size 
    contains the numbers from n to 1, listed in descending order. 

    You'll use the time_to_search function to time each call.

    Usage:
        Run using the default sizes given above:

        results  = benchmark_sorting_algs()

        Run using custom sizes

        results2 = benchmark_sorting_algs([100, 200, 300, 400, 500, 600, 700, 800, 900, 1000])

    Params:
        sizes.......a list of input sizes. For each size, a list
                    of numbers from n to 1 will be generated and
                    selection_sort and merge_sort will be on it.

    Returns:
        A list of tuples of the form
        (n, selection_sort_time, merge_sort_time)
        indicating the number of milliseconds it takes
        for each method to run on each value of n
    """
    # TO-DO: Implement this
    
    results = []

    # For each size, generate a list and benchmark sorting algorithms
    for n in sizes:
        # Create a list in descending order from n to 1
        lst = list(range(n, 0, -1))

        # Measure the time it takes for selection sort
        selection_sort_time = get_sorting_time(selection_sort, lst)

        # Measure the time it takes for merge sort
        merge_sort_time = get_sorting_time(merge_sort, lst)

        # Append the result as a tuple (n, selection_sort_time, merge_sort_time)
        results.append((n, selection_sort_time, merge_sort_time))

    return results

# Example usage
results = benchmark_sorting_algs()
for n, ss_time, ms_time in results:
    print(f"Size: {n}, Selection Sort: {ss_time:.2f} ms, Merge Sort: {ms_time:.2f} ms")

   
   
    #results = []
    #return results

def print_results(results):
    """ done """
    print(tabulate.tabulate(results,
        headers=['n', 'Selection Sort', 'Merge Sort'],
        floatfmt=".3f",
        tablefmt="github"))

   
def plot_results(sizes, ss_times, ms_times):
    """ Generate plots for Selection Sort and Merge Sort runtimes. """
    plt.figure(figsize=(10, 5))
    plt.plot(sizes, ss_times, marker='o', label='Selection Sort')
    plt.plot(sizes, ms_times, marker='x', label='Merge Sort')
    plt.title('Selection Sort vs. Merge Sort Runtimes')
    plt.xlabel('List Size (n)')
    plt.ylabel('Time (milliseconds)')
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == '__main__':
    sizes_1 = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    sizes_2 = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
    sizes_3 = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
    
    # Benchmark the sorting algorithms
    
    results_1 = benchmark_sorting_algs(sizes_1)
    results_2 = benchmark_sorting_algs(sizes_2)
    results_3 = benchmark_sorting_algs(sizes_3)
    
    
    # Extract the results into separate lists for plotting
    sizes_1, ss_times, ms_times = zip(*results_1)
    sizes_2, ss_times, ms_times = zip(*results_2)
    sizes_3, ss_times, ms_times = zip(*results_3)
    
    # printing the table of results
    print_results(results_1)
    print('......................................')
    print_results(results_2)
    print('......................................')
    print_results(results_3)
    
    # Plotting the runtimes of Selection Sort and Merge Sort
    
    plot_results(sizes_1, ss_times, ms_times)
    print('********************************************************************************')
    plot_results(sizes_2, ss_times, ms_times)
    print('********************************************************************************')
    plot_results(sizes_3, ss_times, ms_times)
   
#sizes = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
#results = benchmark_sorting_algs(sizes)
#print_results(results)

#sizes = [1000, 10000, 100000]
#results = benchmark_sorting_algs(sizes)

# Print results
#for n, ss_time, ms_time in results:
    #print(f"Size: {n}, Selection Sort: {ss_time:.2f} ms, Merge Sort: {ms_time:.2f} ms")

#def run_and_plot(sizes, title):
    #results = benchmark_sorting_algs(sizes)
    #selection_sort_times = [result[1] for result in results]
    #merge_sort_times = [result[2] for result in results]
    
    # Print the results in tabular form
    #print_results(results)
    
    # Plotting the results
    #plt.figure(figsize=(10, 6))
    #plt.plot(sizes, selection_sort_times, label='Selection Sort', marker='o')
    #plt.plot(sizes, merge_sort_times, label='Merge Sort', marker='o')
    #plt.xlabel('List Size')
    #plt.ylabel('Time (ms)')
    #plt.title(title)
    #plt.legend()
    #plt.grid(True)
    #plt.show()

# Run for the three different size ranges
#sizes_1 = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
#sizes_2 = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
#sizes_3 = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]

# Generate plots for the given size ranges
#run_and_plot(sizes_1, "Sorting Times for Sizes [10, 20, 30, ..., 100]")
#run_and_plot(sizes_2, "Sorting Times for Sizes [100, 200, 300, ..., 1000]")
#run_and_plot(sizes_3, "Sorting Times for Sizes [1000, 2000, 3000, ..., 10000]")


# Measure the times for specified sizes
#sizes = [1000, 10000, 100000]
#results = benchmark_sorting_algs(sizes)

# Print results
#for n, ss_time, ms_time in results:
    #print(f"Size: {n}, Selection Sort: {ss_time:.2f} ms, Merge Sort: {ms_time:.2f} ms")

#test_unimodal_max()
#test_is_sorted()
#test_selection_sort()
#test_merge_sort()