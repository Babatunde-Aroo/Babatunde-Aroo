"""
CMPS 6100  Lab 6
Author: Augustine Babatunde
"""

from my_queue import Queue
from bst import BST

def breadth_first_search(graph, source):
    visited = set()
    frontier = Queue() # use ops `push` and `poll`
    frontier.push(source)
    while len(frontier) > 0:
        v = frontier.poll()
        if v in visited:
            continue
        
        visited.add(v)
        for neighbor in graph[v]:
            if neighbor not in visited:
                frontier.push(neighbor)
        
    return visited

def bfs_distances(graph, source):
    """
    bfs_distances is a modified version of breadth first 
    search. It traverses the graph in the same order as
    BFS starting from the source and keeps track of the distances
    from each vertex to the source.
    """
    visited = set()
    distances = {vertex: float('inf') for vertex in graph}  # Initialize all distances to infinity
    distances[source] = 0  # Distance to the source is 0
    frontier = Queue()  # Initialize the queue
    frontier.push(source)  # Start BFS with the source

    while not frontier.is_empty():
        v = frontier.poll()
        if v in visited:
            continue
        
        visited.add(v)  # Mark the vertex as visited
        for neighbor in graph.get(v, []):  # Safely access neighbors
            if neighbor not in visited:
                frontier.push(neighbor)
                if distances[neighbor] == float('inf'):  # Update distance if not set
                    distances[neighbor] = distances[v] + 1

    return distances

def connected_components(graph):
    """
    Return the connected components in this graph.
    """
    def dfs(node, component):
        component.add(node)
        for neighbor in graph.get(node, []):  # Safely access neighbors
            if neighbor not in component:
                dfs(neighbor, component)

    visited = set()
    components = []
    for node in graph:
        if node not in visited:
            component = set()
            dfs(node, component)
            components.append(component)
            visited.update(component)  # Mark all nodes in the component as visited

    return components

def num_connected_components(graph):
    """
    Return the number of connected components in this graph.
    """
    components = connected_components(graph)
    return len(components)
