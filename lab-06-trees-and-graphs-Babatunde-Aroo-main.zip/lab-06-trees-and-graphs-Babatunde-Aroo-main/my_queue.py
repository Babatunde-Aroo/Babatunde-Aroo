"""
CMPS 6100  Lab 6
Author: Augustine Babatunde Arogundade
"""

from linked_list import LinkedList

class Queue:
    def __init__(self):
        self.queue = LinkedList()

    def __len__(self):
        return self.queue.size
    
    def is_empty(self):
        return len(self) == 0

    def push(self, element):
        # TO-DO
        # Implement this
        self.queue.append(element)
        #pass

    def poll(self):
        # TO-DO
        # Implement this
        
        if not self.is_empty():
            element = self.queue.get(0)
            self.queue.remove_first()
            return element
        else:
            return None
        #pass

    def peek(self):
        # TO-DO
        # Implement this
     
        if not self.is_empty():
            return self.queue.get(0)
        else:
            return None

        #pass