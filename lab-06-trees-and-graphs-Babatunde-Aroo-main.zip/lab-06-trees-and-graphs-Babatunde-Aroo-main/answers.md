# CMPS 6100 Lab 07
## Answers

**Name:**__Augustine Babatunde Arogundade_____


Place all written answers from `lab-07.md` here.

6. Suppose that you are running Depth First Search (DFS) on a tree. Which of the tree traversals would visit the elements of the tree in a valid order for DFS, that is, in the same order that DFS could?

The tree traversal the elements would visit in a valid order is **preorder traversal**. This matches the behavior of DFS, where you first visit a node, then recursively explore its children, typically starting with the left child before the right.

This could be followed by the **postorder traversal**.