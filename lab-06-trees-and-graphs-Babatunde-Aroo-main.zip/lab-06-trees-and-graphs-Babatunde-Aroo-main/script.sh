# If you're feeling ambitious, you can convert from Markdown to PDF. 
# You'll need to install pandoc (https://pandoc.org/) and latex. Then, run:
pandoc -V geometry:margin=1in answers.md -o answers.pdf