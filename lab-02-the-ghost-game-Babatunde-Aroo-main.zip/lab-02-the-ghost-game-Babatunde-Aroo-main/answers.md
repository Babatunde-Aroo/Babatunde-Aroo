# CMPS 6100 Lab 02
## Answers

**Name:**___Augustine Babatunde Arogundade______________________


Place all written answers from `lab-02.md` here.

- **1)** Note the names of your map input file and map drawing image here. Pro-move: embed your image here.

My layouts of the Game.
![Mansion_Layout][def]

[def]: Lab2_mansion_Img-1.png


![Layout1][def]

[def]: Lab2_Layout2.jpg