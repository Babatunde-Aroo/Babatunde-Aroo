import random

# Room data
room_data = {
    '0': {'name': 'Foyer', 'Exits': {'1': 'West', '3': 'North', '2': 'East'}, 'description': "This is a spacious entryway. There is a portrait of a young couple to the left. The man is wearing a sport's coat with a purple cravat and the woman a lab coat. To the right is a patinaed mirror."},
    '1': {'name': 'Study room', 'Exits': {'0': 'East'}, 'description': "The bookshelves along the walls are disheveled and disorganized. There is a desk on the far wall with drawers open and papers scattered across it. The open chest next to it contains a single empty vial."},
    '2': {'name': 'Den', 'Exits': {'0': 'West'}, 'description': "Den: There is a large sofa, two armchairs, and a large screen TV mounted on the wall. The TV has a large crack across it. There is a shattered vase, desicated plant matter, and a dry water stain below it. There are paintings of row boats and yachts on the walls."},
    '3': {'name': 'Grand Ballroom', 'Exits': {'11': 'West', '8': 'North', '4': 'East', '0': 'South'}, 'description': "There are small tables with tall stools around a dance floor. There is a raised stage in the back right. The floor and stage are made of glass and below it you see rolling water. The ballroom is dark, only illuminated by the scattered light reflecting off the waves below."},
    '4': {'name': 'East Wing Hallway', 'Exits': {'3': 'West', '5': 'North', '6': 'South'}, 'description': "This is a carpeted hallway. There is a stain which has burned through the carpet in front of the north door. At the end of the hallway is statue-like atomic model of what looks like a biological macro-molecule. The plaque says, GP429-TS03.pdb - The key to emergent consciousness"},
    '5': {'name': 'Laboratory', 'Exits': {'4': 'South'}, 'description': "This room stands in stark contrast to the hallway outside. Its floors are white tiles, walls are smooth white plastic. It is illuminated by the flashing and flickering of computer monitors hanging from the ceiling askew on their mounting supports. Between the flickering, on one, there is scrolling text, atoms and coordinates. On another, a model of GP429-TS03, shifting, morphing, and... growing? On the left wall is a workbench with a shattered ventilation hood, fan sputtering."},
    '6': {'name': 'Master Bedroom', 'Exits': {'4': 'North', '7': 'East'}, 'description': "This room is in perfect order. There is a four posted bed, made, covered in throws and pillows. There is a reading chair in the corner with The Confessions of Arsene Lupin open on a stand next to it."},
    '7': {'name': 'Master Bathroom', 'Exits': {'6': 'West'}, 'description': "The walk-in shower is luxurious. The double vanity is topped with creams, perfumes, lotions, oils, and a box of sheet masks. There is a damp towel hanging on a hook."},
    '8': {'name': 'Dining Room', 'Exits': {'9': 'West', '3': 'South'}, 'description': "There is a large black aluminum and glass table in the center surrounded by molded black shell chairs. The back wall is a window through which you see waves and rolling fog. The mast of a sailboat protrudes from the waves."},
    '9': {'name': 'Kitchen', 'Exits': {'10': 'North', '8': 'East'}, 'description': "The kitchen is spacious and luxurious. There are two oversized fridges with transparent doors. The food is fresh. On the island is an open tin of kerosene. On the floor is a mop handle. The mop head is burnt to ash."},
    '10': {'name': 'Pantry', 'Exits': {'9': 'South'}, 'description': "The walls are lined with shelves. Bulk goods are organized into containers. There is an airtight container filled with dog food. Everything is in order except for the shelf with cleaning agents and household liquids. These are knocked aside and there is a gap in the middle."},
    '11': {'name': 'West Wing Hallway', 'Exits': {'15': 'West', '13': 'North', '3': 'East', '12': 'South'}, 'description': "This is a carpeted hallway. On a side table is a bust of a woman. The plaque says Ada Lovelace - Let your vision become reality."},
    '12': {'name': 'General Storage Room', 'Exits': {'11': 'North'}, 'description': "The room is packed with tables, chairs, and paintings. There are three cracked mirrors, a box of old keyboards and cables, and an PDP 11 pushed into the corner."},
    '13': {'name': 'Antechamber', 'Exits': {'14': 'North', '11': 'South'}, 'description': "This room looks like a quest room except that it is nearly empty except for cobwebs stretching from the chandelier, single crystal clear standing mirror in the corner, and an empty bookcase standing ajar against the back wall."},
    '14': {'name': 'Beautiful Bedroom', 'Exits': {'13': 'South'}, 'description': "This room is beautifully appointed. There is a rosewood desk with a closed laptop on top of it. Against the wall is a bookcase containing Meditations by Marcus Aurelius, a yellowed PDP-11 user manual, the Complete Sherlock Holmes, and The C Programming Language by Kernighan and Ritchie. An ivy vine frames the window and doorframe. On the bed lays a man with a purple cravat and an IV embedded in his arm."},
    '15': {'name': 'Water Closet', 'Exits': {'11': 'East'}, 'description': "This guest bathroom is simple but functional. There is a shower, a razor on the counter, and a strop hanging on the wall."}
}

# Combat
def player_attack():
    print("\nChoose your attack:")
    print("1. Slash - Deals 10 damage")
    print("2. Stab - Deals 15 damage")
    print("3. Kick - Deals 8 damage and stuns the zombie for one turn")
    attack_choice = input("Enter the number of your attack choice: ")
    
    if attack_choice == '1':
        return 10, False
    elif attack_choice == '2':
        return 15, False
    elif attack_choice == '3':
        return 8, True
    else:
        print("Are you tired? \nZombie attacks.")
        return 0, False

def zombie_attack(player_hp):
    # Two attack options: Bite and Claw
    attack_type = 'Bite' if player_hp < 30 and random.random() > 0.3 else 'Claw'  # ikelihood of the zombie choosing the "Bite" attack.
    
    if attack_type == 'Bite':
        damage = random.randint(15, 20)
        print(f"\nThe zombie uses Bite and deals {damage} damage!")
    else:
        damage = random.randint(7, 14)
        print(f"\nThe zombie uses Claw and deals {damage} damage!")

    return damage

def combat_loop():
    player_hp = 150
    zombie_hp = 150
    zombie_stunned = False            # zombie is temporarily unable to attack

    while player_hp > 0 and zombie_hp > 0:
        print(f"\nYour HP: {player_hp} | Zombie HP: {zombie_hp}")
        
        # Player's turn
        attack_damage, stun = player_attack()
        zombie_hp -= attack_damage
        if stun:
            print("The zombie is stunned and misses its next attack!")
            zombie_stunned = True
        else:
            zombie_stunned = False
        
        if zombie_hp <= 0:
            print("\nYou defeated the zombie! You can now continue exploring.")
            return True

        # Zombie's turn
        if not zombie_stunned:
            damage = zombie_attack(player_hp)
            player_hp -= damage
        else:
            print("\nThe zombie is stunned and misses its attack.")
        
        if player_hp <= 0:
            print("\nYou have been defeated by the zombie. Game Over!")
            return False

# Main game loop
while True:
    Zombieroom = random.randint(1, 15)
    Portkey = random.randint(1, 15)

    if Zombieroom != Portkey:
        break

print("Welcome to The Zombie Game!")
print("You are in a haunted mansion. Find the portkey to escape, but beware of the Zombie!")
print(f"The Zombie is in room {Zombieroom}")
print(f"The portkey room with the keys for escaping is {Portkey}\n")

ID = '0'

while True:
    print(f"\nYou are now in {room_data[ID]['name']}.")
    print(room_data[ID]['description'])

    # Check if player encounters the portkey
    if int(ID) == Portkey:
        print('\nYou found the portkey room, but you must defeat the zombie here to win the game.')
        if combat_loop():
            print("\nCongratulations! You won!")
        break

    # Check if player encounters the zombie
    if int(ID) == Zombieroom:
        print('\nOoops! \nYou ended up in the Zombie room.\nYou must defeat the zombie here to win the game.')
        if combat_loop():
            print("\nCongratulations! You won!")
            ID = '0'
        else:
            break

    else:
        exits = room_data[ID]['Exits']
        valid_exits = list(exits.keys())
        print(f"\nYou can ONLY go to rooms with room ID's and corresponding directions {set(room_data[ID]['Exits'].items())}.\n")
        next_room = input('What room do you want to go to next?: ')

        if next_room not in valid_exits:
            print("\nWrong input. \nYou can only choose one of the available exits in the room. Try again!")
            #break

        else:
            ID = next_room
