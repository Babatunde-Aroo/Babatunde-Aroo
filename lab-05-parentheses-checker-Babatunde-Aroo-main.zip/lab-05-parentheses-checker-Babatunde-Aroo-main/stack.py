from linked_list import LinkedList

class Stack:
    def __init__(self):
        self.stack = LinkedList()
    
    def is_empty(self):
        return self.stack.size == 0

    def push(self, element):
        # TO-DO
        # Implement this
        # Add the element to the top of the stack
        self.stack.prepend(element)
    
        #pass

    def pop(self):
        # TO-DO
        # Implement this
        # Return the top element and remove it from the stack
        if self.is_empty():
            return None
        top_element = self.stack.get(0)
        self.stack.remove_first()
        return top_element
        #pass

    def top(self):
        # TO-DO
        # Implement this
        # Return the top element without removing it
        if self.is_empty():
            return None
        return self.stack.get(0)
        #pass