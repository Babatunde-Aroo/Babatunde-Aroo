"""
CMPS 6100  Lab 5
Author: Augustine Babatunde Arogundade
"""

## imports
from stack import Stack

def are_parentheses_matched(string):
    # TO-DO
    # Implement this
    stack = Stack()
    
    for character in string:
        if character == "(":
            stack.push(character)      # Push opening parenthesis onto the stack
        elif character == ")":
           
            if stack.is_empty():
                return False
            stack.pop()
    
    # If the stack is empty, all parentheses were matched.
    return stack.is_empty()
    #pass