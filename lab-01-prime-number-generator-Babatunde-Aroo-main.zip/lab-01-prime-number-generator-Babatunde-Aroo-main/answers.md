# CMPS 6100 Lab 01
## Answers

**Name:**_Augustine Babatunde Arogundade_


Place all written answers from `lab-01.md` here.

- **11)** What is the largest pair of twin primes that you generated and how long did it take? (881, 883) are the largest pairs of twin prime of 1000 that I generated. It took 0.58 milliseconds.
