"""
CMPS 6100  Lab 1
Author: Augustine Babatunde Arogundade
"""

### the only imports needed are here
import math
import time
###

def is_divisible_by(num, i):
    if i == 0:
        print("The divisor cannot be zero.")
    else:
        return num % i == 0
divisible = is_divisible_by (5,2)
#print(divisible)
   


def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, int(math.sqrt(num)) + 1):
        if num % i == 0:
            return False
    
    return True
prime = is_prime(5)
#print(prime)
    

def generate_primes(upper_bound):
    #Generate a list of prime numbers up to a specified limit.
    primes = []             # this list will contain the prime numbers at the end
    for num in range(2, upper_bound):
        if is_prime(num):
            primes.append(num)
    return primes

upper_bound = 1000            # the specified upper_bound limit to generate_prime
#print(f"Prime numbers up to {upper_bound}: {generate_primes(upper_bound)}")
 

def count_primes(upper_bound):
    count = 0
    for num in range(2, upper_bound):
        if is_prime(num):
            count += 1
    return count
#print(f"Number of prime numbers less than {upper_bound}: {count_primes(upper_bound)}")


def generate_twin_primes(upper_bound):
    twin_primes = []                        # this list will contain the twin_prime numbers at the end
    
    for num in range(2, upper_bound-1):  # Check up to upper_bound - 2 (take note)
        if is_prime(num) and is_prime(num + 2):
            twin_primes.append((num, num + 2))
    
    return twin_primes
#print(f"Twin primes less than {upper_bound}: {generate_twin_primes(upper_bound)}")



def count_twin_primes(upper_bound):
    count = 0
    
    for num in range(2, upper_bound - 1):  # Check up to upper_bound - 2 (take note)
        if is_prime(num) and is_prime(num + 2):
            count += 1
    
    return count

#print(f"Number of twin primes less than {upper_bound}: {count_twin_primes(upper_bound)}")




#########    #########
### Test Functions ###
#########    #########

# You can run them on the terminal.
# The command:
#
# pytest main.py::test_is_divisible_by
#
# Will run the test_is_divisible_by test function.

def test_is_divisible_by():
    assert is_divisible_by(2, 2) == True
    assert is_divisible_by(3, 2) == False
    assert is_divisible_by(47, 7) == False

def test_is_prime():
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 241, 461, 701, 881, 883, 997]
    for prime in primes:
        assert is_prime(prime) == True
    composites = [4, 6, 8, 9, 10, 25, 30, 36, 39, 49, 60, 64, 121]
    for composite in composites:
        assert is_prime(composite) == False

def test_count_primes():
    assert count_primes(10) == 4
    assert count_primes(100) == 25
    assert count_primes(1000) == 168
    assert count_primes(10000) == 1229

def test_count_twin_primes():
    assert count_twin_primes(10) == 2
    # The two pairs less than 10 are (3,5) and (5,7)
    assert count_twin_primes(100) == 8
    assert count_twin_primes(1000) == 35
    assert count_twin_primes(10000) == 205


print(divisible)
print(prime)
print(f"Prime numbers up to {upper_bound}: {generate_primes(upper_bound)}")
print(f"Number of prime numbers less than {upper_bound}: {count_primes(upper_bound)}")
print(f"Twin primes less than {upper_bound}: {generate_twin_primes(upper_bound)}")
print(f"Number of twin primes less than {upper_bound}: {count_twin_primes(upper_bound)}")


start = time.time()
generate_twin_primes(1000)
end = time.time()

elapsed_time_ms = (end-start) * 1000
print("Elapsed Time: {:.2f} milliseconds" .format(elapsed_time_ms))